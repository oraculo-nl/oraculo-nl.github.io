from datetime import datetime

# current date and time
now = datetime.now()

print(now)