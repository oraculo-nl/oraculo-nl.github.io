with open('resource/data.csv', newline='') as f:
    reader = csv.reader(f)
    for row in reader:
        posts.append(row)
