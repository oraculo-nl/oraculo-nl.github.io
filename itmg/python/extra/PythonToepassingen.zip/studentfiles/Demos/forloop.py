cars = ['volvo','fiat','mazda']
for car in cars:
    print(car)