def main():
    phrase = input("Choose a phrase: ")
    # Write your code here

main()