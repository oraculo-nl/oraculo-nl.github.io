def main():
    colors = ['red', 'blue', 'green', 'orange', 'purple']
    print(min(colors))

    ages = (27, 4, 15, 99, 33, 25)
    print(max(ages))

main()