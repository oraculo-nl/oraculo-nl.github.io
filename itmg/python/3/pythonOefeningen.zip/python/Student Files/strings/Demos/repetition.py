one_knight_says = "nee"
many_knights_say = one_knight_says * 20
print(many_knights_say)