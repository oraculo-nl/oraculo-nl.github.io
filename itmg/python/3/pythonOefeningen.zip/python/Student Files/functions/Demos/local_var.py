def set_x():
    x = 1

def get_x():
    print(x)

def main():
    set_x()
    get_x()

main()